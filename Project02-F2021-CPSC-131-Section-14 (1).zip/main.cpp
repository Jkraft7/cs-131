#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN

#include <exception>

#include "doctest.hpp"

#include "book_test.hpp"
#include "book_list_test.hpp"