#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN

#include "doctest.hpp"

#include "book_database_test.hpp"
#include "checkout_test.hpp"